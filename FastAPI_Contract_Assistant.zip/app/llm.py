import requests
from app.schemas import SCHEMAS

def llama_answer(user_input: str, active_schema: str = None, current_field: str = None, current_question: str = None) -> str:
    schema_valid = active_schema in SCHEMAS
    followup = "Shall we return to filling in the contract?" if schema_valid else "Would you like to begin by choosing a document type?"

    if schema_valid and current_field and current_question:
        prompt = f"""You are a document assistant helping fill out a {SCHEMAS[active_schema]['display_name']}.
User has been asked: {current_question}
User: {user_input}
Respond with a short, helpful explanation. Then say: {followup}
""""
    else:
        prompt = f"""You only generate these two contract types:
- Rental Agreement (rental_agreement)
- Non-Disclosure Agreement (nda)
User: {user_input}
Assistant:"""    

    res = requests.post("http://localhost:11434/api/generate", json={"model": "llama3:8b", "prompt": prompt, "stream": False})
    response = res.json().get("response", "[LLM error]")
    return f"{response.strip()}\n\n{followup}" if followup not in response else response.strip()
