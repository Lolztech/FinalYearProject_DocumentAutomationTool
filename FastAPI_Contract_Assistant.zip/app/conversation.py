from app.schemas import SCHEMAS
from app.llm import llama_answer

class ConversationState:
    def __init__(self):
        self.active_schema = None
        self.current_field_index = None
        self.slots = {}

    def reset(self):
        self.active_schema = None
        self.current_field_index = None
        self.slots = {}

    def handle_user_message(self, user_input: str) -> str:
        if not self.active_schema:
            if "rental" in user_input.lower():
                self.active_schema = "rental_agreement"
            elif "nda" in user_input.lower():
                self.active_schema = "nda"
            else:
                return llama_answer(user_input)

            self.current_field_index = 0
            return f"Great! Let's create a {SCHEMAS[self.active_schema]['display_name']}.
" +                    "I'll ask you questions to fill it in. Say 'I'm ready' when you are."

        if "ready" in user_input.lower() and self.current_field_index is not None:
            question = SCHEMAS[self.active_schema]['fields'][self.current_field_index]["question"]
            return question

        if self.current_field_index is not None:
            current_field = SCHEMAS[self.active_schema]['fields'][self.current_field_index]
            self.slots[current_field["name"]] = user_input
            self.current_field_index += 1

            if self.current_field_index >= len(SCHEMAS[self.active_schema]['fields']):
                return f"✅ All required fields collected: {self.slots}"

            next_q = SCHEMAS[self.active_schema]['fields'][self.current_field_index]["question"]
            return next_q

        return llama_answer(user_input, self.active_schema)
