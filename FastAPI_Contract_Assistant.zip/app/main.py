from fastapi import FastAPI, Request
from pydantic import BaseModel
from app.llm import llama_answer
from app.conversation import ConversationState

app = FastAPI()
state = ConversationState()

class Message(BaseModel):
    text: str

@app.post("/chat")
async def chat(msg: Message):
    reply = state.handle_user_message(msg.text)
    return {"response": reply}
