SCHEMAS = {
    "rental_agreement": {
        "display_name": "Rental Agreement",
        "fields": [
            {"name": "tenant_name", "question": "What is the tenant's name?"},
            {"name": "landlord_name", "question": "What is the landlord's name?"},
            {"name": "property_address", "question": "What is the rental property address?"},
            {"name": "monthly_rent", "question": "How much is the monthly rent?"},
            {"name": "deposit_amount", "question": "What is the deposit amount?"},
            {"name": "lease_term", "question": "How long is the lease term?"}
        ]
    },
    "nda": {
        "display_name": "Non-Disclosure Agreement (NDA)",
        "fields": [
            {"name": "disclosing_party", "question": "Who is the disclosing party?"},
            {"name": "receiving_party", "question": "Who is the receiving party?"},
            {"name": "purpose", "question": "What is the purpose of the NDA?"}
        ]
    }
}
